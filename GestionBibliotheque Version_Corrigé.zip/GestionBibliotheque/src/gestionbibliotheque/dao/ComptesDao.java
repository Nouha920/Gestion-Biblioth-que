package gestionbibliotheque.dao;

import gestionbibliotheque.util.DBConnexion;

import java.sql.*;

public class ComptesDao {

    public boolean verifierCompte(String email, String motDePasse) throws SQLException {
        String sql = "SELECT * FROM comptes WHERE email=? AND mot_de_passe=?";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, motDePasse);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
    }

   public boolean ajouterCompte(String email, String motDePasse) throws SQLException {
        String sql = "INSERT INTO comptes (email, mot_de_passe) VALUES (?, ?)";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            stmt.setString(2, motDePasse);
            stmt.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // email déjà utilisé
        }
    }
}
