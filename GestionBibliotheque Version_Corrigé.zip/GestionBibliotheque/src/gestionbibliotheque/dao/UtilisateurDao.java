package gestionbibliotheque.dao;

import gestionbibliotheque.model.Utilisateur;
import gestionbibliotheque.util.DBConnexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtilisateurDao {

    // ➕ Ajouter un utilisateur
    public void ajouterUtilisateur(Utilisateur u) throws SQLException {
        String sql = "INSERT INTO utilisateur (nom, prenom, numero_adhérent) VALUES (?, ?, ?)";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, u.getNom());
            stmt.setString(2, u.getPrenom());
            stmt.setString(3, u.getNumeroAdherent());
            stmt.executeUpdate();
        }
    }

    // 📋 Lister tous les utilisateurs
    public List<Utilisateur> listerUtilisateurs() throws SQLException {
        List<Utilisateur> utilisateurs = new ArrayList<>();
        String sql = "SELECT * FROM utilisateur";
        try (Connection conn = DBConnexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                utilisateurs.add(new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("numero_adhérent")
                ));
            }
        }
        return utilisateurs;
    }

    // ❌ Supprimer un utilisateur (et ses emprunts)
    public void supprimerUtilisateur(int id) throws SQLException {
        try (Connection conn = DBConnexion.getConnection()) {

            // Supprimer d'abord les emprunts liés
            String deleteEmprunts = "DELETE FROM emprunt WHERE id_utilisateur=?";
            try (PreparedStatement stmt1 = conn.prepareStatement(deleteEmprunts)) {
                stmt1.setInt(1, id);
                stmt1.executeUpdate();
            }

            // Ensuite supprimer l'utilisateur
            String deleteUser = "DELETE FROM utilisateur WHERE id=?";
            try (PreparedStatement stmt2 = conn.prepareStatement(deleteUser)) {
                stmt2.setInt(1, id);
                stmt2.executeUpdate();
            }
        }
    }

    // 🔍 Rechercher par nom ou numéro d'adhérent
    public List<Utilisateur> rechercherParNomOuNumero(String motCle) throws SQLException {
        List<Utilisateur> utilisateurs = new ArrayList<>();
        String sql = "SELECT * FROM utilisateur WHERE nom LIKE ? OR numero_adhérent LIKE ?";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            String pattern = "%" + motCle + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Utilisateur u = new Utilisateur(
                    rs.getInt("id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("numero_adhérent")
                );
                utilisateurs.add(u);
            }
        }
        return utilisateurs;
    }
    public void modifierUtilisateur(Utilisateur u) throws SQLException {
    String sql = "UPDATE utilisateur SET nom=?, prenom=?, numero_adhérent=? WHERE id=?";
    try (Connection conn = DBConnexion.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, u.getNom());
        stmt.setString(2, u.getPrenom());
        stmt.setString(3, u.getNumeroAdherent());
        stmt.setInt(4, u.getId());
        stmt.executeUpdate();
    }
}

}
