package gestionbibliotheque.ui;

import gestionbibliotheque.dao.UtilisateurDao;
import gestionbibliotheque.model.Utilisateur;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
public class UtilisateurPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private UtilisateurDao utilisateurDao = new UtilisateurDao();
      
    public UtilisateurPanel() {
       setLayout(new BorderLayout());
    this.setBackground(Color.WHITE); // Fond clair

    // 🔹 Titre
    JLabel titre = new JLabel("📚 Gestion des Utilisateurs");
    titre.setHorizontalAlignment(SwingConstants.CENTER);
    titre.setFont(new Font("Segoe UI", Font.BOLD, 22));
    titre.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
    add(titre, BorderLayout.NORTH);

        // 🔍 Barre de recherche

        JPanel searchPanel = new JPanel();
        JTextField searchField = new JTextField(20);
        JButton searchBtn = new JButton("Rechercher");
        searchPanel.add(new JLabel("🔍 Nom ou N° adhérent :"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);
        
JPanel headerPanel = new JPanel(new BorderLayout());
headerPanel.add(titre, BorderLayout.NORTH);
headerPanel.add(searchPanel, BorderLayout.SOUTH);
add(headerPanel, BorderLayout.NORTH);

        // 📋 Tableau
        model = new DefaultTableModel(
                new String[]{"ID", "Nom", "Prénom", "Numéro Adhérent"}, 0
        );
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔘 Boutons
        JButton ajouterBtn = new JButton("Ajouter Utilisateur");

        JButton modifierBtn = new JButton("Modifier");
        modifierBtn.setBackground(new Color(23, 162, 184)); // Bleu clair
        modifierBtn.setForeground(Color.WHITE);

        JButton supprimerBtn = new JButton("Supprimer");
        supprimerBtn.setBackground(new Color(220, 53, 69));
        supprimerBtn.setForeground(Color.WHITE);

        JPanel boutonsPanel = new JPanel();
        boutonsPanel.add(ajouterBtn);
        boutonsPanel.add(modifierBtn);
        boutonsPanel.add(supprimerBtn);
        add(boutonsPanel, BorderLayout.SOUTH);

        // ✅ Action : Ajouter utilisateur
        ajouterBtn.addActionListener(e -> ajouterUtilisateur());

        // ✅ Action : Rechercher
        searchBtn.addActionListener(e -> {
            String motCle = searchField.getText().trim();
            if (!motCle.isEmpty()) {
                rechercherUtilisateurs(motCle);
            } else {
                rafraichirTable(); // tout afficher
            }
        });

        // ✅ Action : Modifier utilisateur
        modifierBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                int id = (int) model.getValueAt(selectedRow, 0);
                String nom = JOptionPane.showInputDialog("Nouveau nom", model.getValueAt(selectedRow, 1));
                String prenom = JOptionPane.showInputDialog("Nouveau prénom", model.getValueAt(selectedRow, 2));
                String numero = JOptionPane.showInputDialog("Nouveau numéro d'adhérent", model.getValueAt(selectedRow, 3));

                try {
                    Utilisateur u = new Utilisateur(id, nom, prenom, numero);
                    utilisateurDao.modifierUtilisateur(u);
                    rafraichirTable();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "❌ Erreur dans les champs.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "❗ Sélectionnez un utilisateur à modifier.");
            }
        });

        // ✅ Action : Supprimer utilisateur
        supprimerBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                int id = (int) model.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this, "Supprimer cet utilisateur ?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        utilisateurDao.supprimerUtilisateur(id);
                        rafraichirTable();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "❌ Impossible de supprimer cet utilisateur.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "❗ Sélectionnez une ligne.");
            }
        });

        // ✅ Chargement initial
        rafraichirTable();
    }

    private void ajouterUtilisateur() {
        try {
            String nom = JOptionPane.showInputDialog("Nom");
            if (nom == null || nom.trim().isEmpty()) return;

            String prenom = JOptionPane.showInputDialog("Prénom");
            if (prenom == null || prenom.trim().isEmpty()) return;

            String numero = JOptionPane.showInputDialog("Numéro d'adhérent");
            if (numero == null || numero.trim().isEmpty()) return;

            Utilisateur u = new Utilisateur(nom, prenom, numero);
            utilisateurDao.ajouterUtilisateur(u);
            rafraichirTable();
            JOptionPane.showMessageDialog(this, "✅ Utilisateur ajouté !");
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Erreur lors de l'ajout de l'utilisateur.");
        }
    }

    private void rafraichirTable() {
        try {
            List<Utilisateur> utilisateurs = utilisateurDao.listerUtilisateurs();
            model.setRowCount(0);
            for (Utilisateur u : utilisateurs) {
                model.addRow(new Object[]{
                        u.getId(), u.getNom(), u.getPrenom(), u.getNumeroAdherent()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void rechercherUtilisateurs(String motCle) {
        try {
            List<Utilisateur> utilisateurs = utilisateurDao.rechercherParNomOuNumero(motCle);
            model.setRowCount(0);
            for (Utilisateur u : utilisateurs) {
                model.addRow(new Object[]{
                        u.getId(), u.getNom(), u.getPrenom(), u.getNumeroAdherent()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
