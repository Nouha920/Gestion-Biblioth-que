package gestionbibliotheque.ui;

import gestionbibliotheque.dao.ComptesDao;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class RegisterFrame extends JFrame {
    public RegisterFrame() {
        setTitle("📝 Inscription");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel form = new JPanel(new GridLayout(3, 2, 10, 10));
        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JPasswordField confirmField = new JPasswordField();

        form.setBorder(BorderFactory.createEmptyBorder(20, 40, 10, 40));
        form.add(new JLabel("📧 Email :"));
        form.add(emailField);
        form.add(new JLabel("🔐 Mot de passe :"));
        form.add(passwordField);
        form.add(new JLabel("✅ Confirmer :"));
        form.add(confirmField);

        JButton submitBtn = new JButton("S’inscrire");
        submitBtn.setBackground(new Color(0, 123, 255));
        submitBtn.setForeground(Color.WHITE);

        add(new JLabel("Formulaire d'inscription", SwingConstants.CENTER), BorderLayout.NORTH);
        add(form, BorderLayout.CENTER);
        add(submitBtn, BorderLayout.SOUTH);

        submitBtn.addActionListener(e -> {
            String email = emailField.getText().trim();
            String pass = new String(passwordField.getPassword());
            String confirm = new String(confirmField.getPassword());

            if (email.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
                JOptionPane.showMessageDialog(this, "❌ Tous les champs sont obligatoires.");
                return;
            }

            if (!pass.equals(confirm)) {
                JOptionPane.showMessageDialog(this, "❌ Les mots de passe ne correspondent pas.");
                return;
            }

            try {
                ComptesDao dao = new ComptesDao();
                boolean success = dao.ajouterCompte(email, pass);

                if (success) {
                    JOptionPane.showMessageDialog(this, "✅ Inscription réussie !");
                    dispose(); // Fermer la fenêtre
                    new LoginFrame().setVisible(true); // Retour à la connexion
                } else {
                    JOptionPane.showMessageDialog(this, "❌ Email déjà utilisé !");
                }

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "❌ Erreur lors de l'inscription !");
            }
        });
    }
}
