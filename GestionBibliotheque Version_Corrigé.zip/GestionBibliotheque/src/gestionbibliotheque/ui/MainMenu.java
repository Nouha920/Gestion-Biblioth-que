package gestionbibliotheque.ui;

import javax.swing.*;
import java.awt.*;

public class MainMenu extends JFrame {
    public MainMenu() {
        setTitle("📚 Gestion de la Bibliothèque");
        setSize(900, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // 🔵 Titre stylé en haut
        JLabel titre = new JLabel("📚 Application de Gestion de Bibliothèque");
        titre.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titre.setHorizontalAlignment(SwingConstants.CENTER);
        titre.setOpaque(true);
        titre.setBackground(new Color(62, 152, 219)); // bleu clair
        titre.setForeground(Color.WHITE);
        titre.setBorder(BorderFactory.createEmptyBorder(15, 10, 15, 10));

        add(titre, BorderLayout.NORTH);

        // 🟡 Onglets avec icônes et couleurs
        JTabbedPane tabs = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        tabs.addTab(" Livres", new LivrePanel());
        tabs.addTab(" Utilisateurs", new UtilisateurPanel());
        tabs.addTab(" Emprunts", new EmpruntPanel());

      
        add(tabs, BorderLayout.CENTER);
    }
}
