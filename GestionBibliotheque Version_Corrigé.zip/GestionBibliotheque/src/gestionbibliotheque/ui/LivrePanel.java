package gestionbibliotheque.ui;

import gestionbibliotheque.dao.LivreDao;
import gestionbibliotheque.model.Livre;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class LivrePanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private LivreDao livreDao = new LivreDao();

    public LivrePanel() {
        setLayout(new BorderLayout());
        this.setBackground(new Color(255, 255, 255)); // Fond clair

        // 🔹 Titre
        JLabel titre = new JLabel("📚 Gestion des Livres");
        titre.setHorizontalAlignment(SwingConstants.CENTER);
        titre.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titre.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 🔍 Recherche
        JPanel searchPanel = new JPanel();
        JTextField searchField = new JTextField(20);
        JButton searchBtn = new JButton("Rechercher");

        searchBtn.setBackground(new Color(255, 193, 7)); // Jaune
        searchBtn.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        searchPanel.add(new JLabel("🔍 Titre ou Auteur :"));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);

        // Regrouper titre et recherche
        JPanel header = new JPanel(new BorderLayout());
        header.add(titre, BorderLayout.NORTH);
        header.add(searchPanel, BorderLayout.SOUTH);
        add(header, BorderLayout.NORTH);

        // 🟦 Tableau
        model = new DefaultTableModel(
                new String[]{"ID", "Titre", "Auteur", "ISBN", "Année", "Exemplaires"}, 0
        );
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔘 Boutons
        JButton ajouterBtn = new JButton("Ajouter Livre");
        ajouterBtn.setBackground(new Color(0, 123, 255));
        ajouterBtn.setForeground(Color.WHITE);
        ajouterBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JButton modifierBtn = new JButton("Modifier");
        modifierBtn.setBackground(new Color(23, 162, 184));
        modifierBtn.setForeground(Color.WHITE);

        JButton supprimerBtn = new JButton("Supprimer");
        supprimerBtn.setBackground(new Color(220, 53, 69));
        supprimerBtn.setForeground(Color.WHITE);

        JPanel boutonsPanel = new JPanel();
        boutonsPanel.add(ajouterBtn);
        boutonsPanel.add(modifierBtn);
        boutonsPanel.add(supprimerBtn);
        add(boutonsPanel, BorderLayout.SOUTH);

        // Action Ajouter
        ajouterBtn.addActionListener(e -> ajouterLivre());

        // Action Rechercher
        searchBtn.addActionListener(e -> {
            String motCle = searchField.getText().trim();
            if (!motCle.isEmpty()) {
                rechercherLivres(motCle);
            } else {
                rafraichirTable();
            }
        });

        // Action Modifier
        modifierBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                int id = (int) model.getValueAt(selectedRow, 0);
                String nouveauTitre = JOptionPane.showInputDialog("Nouveau titre", model.getValueAt(selectedRow, 1));
                String nouvelAuteur = JOptionPane.showInputDialog("Nouvel auteur", model.getValueAt(selectedRow, 2));
                String nouveauIsbn = JOptionPane.showInputDialog("Nouveau ISBN", model.getValueAt(selectedRow, 3));
                String anneeStr = JOptionPane.showInputDialog("Nouvelle année", model.getValueAt(selectedRow, 4));
                String nbExStr = JOptionPane.showInputDialog("Nouveaux exemplaires", model.getValueAt(selectedRow, 5));

                try {
                    int annee = Integer.parseInt(anneeStr);
                    int nbEx = Integer.parseInt(nbExStr);
                    Livre livre = new Livre(id, nouveauTitre, nouvelAuteur, nouveauIsbn, annee, nbEx);
                    livreDao.modifierLivre(livre);
                    rafraichirTable();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "❌ Erreur dans les champs.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "❗ Sélectionne un livre à modifier.");
            }
        });

        // Action Supprimer
        supprimerBtn.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow >= 0) {
                int id = (int) model.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(this, "Confirmer la suppression ?", "Supprimer", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        livreDao.supprimerLivre(id);
                        rafraichirTable();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "❌ Impossible de supprimer ce livre.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "❗ Sélectionne un livre à supprimer.");
            }
        });

        // Remplir tableau au démarrage
        rafraichirTable();
    }

    private void ajouterLivre() {
        try {
            String titre = JOptionPane.showInputDialog("Titre");
            if (titre == null || titre.trim().isEmpty()) return;

            String auteur = JOptionPane.showInputDialog("Auteur");
            if (auteur == null || auteur.trim().isEmpty()) return;

            String isbn = JOptionPane.showInputDialog("ISBN");
            if (isbn == null || isbn.trim().isEmpty()) return;

            String anneeStr = JOptionPane.showInputDialog("Année");
            if (anneeStr == null || anneeStr.trim().isEmpty()) return;
            int annee = Integer.parseInt(anneeStr);

            String nbExStr = JOptionPane.showInputDialog("Nombre d'exemplaires");
            if (nbExStr == null || nbExStr.trim().isEmpty()) return;
            int nbEx = Integer.parseInt(nbExStr);

            Livre livre = new Livre(titre, auteur, isbn, annee, nbEx);
            livreDao.ajouterLivre(livre);
            rafraichirTable();
            JOptionPane.showMessageDialog(this, "✅ Livre ajouté !");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Erreur lors de l'ajout.");
        }
    }

    private void rafraichirTable() {
        try {
            List<Livre> livres = livreDao.listerLivres();
            model.setRowCount(0);
            for (Livre l : livres) {
                model.addRow(new Object[]{
                        l.getId(), l.getTitre(), l.getAuteur(),
                        l.getIsbn(), l.getAnnee(), l.getNbExemplaires()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void rechercherLivres(String motCle) {
        try {
            List<Livre> livres = livreDao.rechercherParTitreOuAuteur(motCle);
            model.setRowCount(0);
            for (Livre l : livres) {
                model.addRow(new Object[]{
                        l.getId(), l.getTitre(), l.getAuteur(),
                        l.getIsbn(), l.getAnnee(), l.getNbExemplaires()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}
