package gestionbibliotheque.ui;
import gestionbibliotheque.dao.ComptesDao;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    private final Color PRIMARY_COLOR = new Color(25, 118, 210);    // Bleu primaire
    private final Color ACCENT_COLOR = new Color(245, 124, 0);      // Orange accent
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Gris clair
    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 22);
    private final Font REGULAR_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    public LoginFrame() {
        setTitle("Bibliothèque - Connexion");
        setSize(480, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(20, 20));
        setResizable(false);
        getContentPane().setBackground(BACKGROUND_COLOR);

        JPanel mainPanel = createShadowPanel();
        mainPanel.setLayout(new BorderLayout(0, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));

        // 🔹 En-tête
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("📚 Bibliothèque Municipale");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel subtitleLabel = new JLabel("Système de gestion", SwingConstants.CENTER);
        subtitleLabel.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        subtitleLabel.setForeground(new Color(120, 120, 120));

        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setOpaque(false);
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);

        headerPanel.add(titlePanel, BorderLayout.CENTER);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // 🔐 Formulaire de connexion
        JPanel formPanel = new JPanel(new GridLayout(3, 1, 0, 15));
        formPanel.setOpaque(false);

        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        formPanel.add(createLabeledField("Adresse e-mail", emailField));
        formPanel.add(createLabeledField("Mot de passe", passwordField));

        JButton loginButton = new JButton("SE CONNECTER");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(PRIMARY_COLOR);
        loginButton.setFocusPainted(false);
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginButton.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

        // Effet survol
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(30, 136, 229));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(PRIMARY_COLOR);
            }
        });

        formPanel.add(loginButton);
        mainPanel.add(formPanel, BorderLayout.CENTER);

        // 🔘 Boutons secondaires
        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(BACKGROUND_COLOR);

        JButton registerBtn = new JButton("S’inscrire");
        registerBtn.setForeground(PRIMARY_COLOR);
        registerBtn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        registerBtn.setBorderPainted(false);
        registerBtn.setContentAreaFilled(false);
        registerBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        btnPanel.add(registerBtn);
        mainPanel.add(btnPanel, BorderLayout.SOUTH);

        // ✅ Action Connexion
       loginButton.addActionListener(e -> {
    String email = emailField.getText().trim();
    String password = new String(passwordField.getPassword()).trim();

    try {
        ComptesDao dao = new ComptesDao();

        if (dao.verifierCompte(email, password) || (email.equals("admin@gmail.com") && password.equals("admin123"))) {
            JOptionPane.showMessageDialog(this, "✅ Connexion réussie !");
            dispose();
            new MainMenu().setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "❌ Identifiants incorrects !");
        }
    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(this, "❌ Erreur de connexion à la base.");
    }
});


        // ✅ Action Inscription
        registerBtn.addActionListener(e -> {
            new RegisterFrame().setVisible(true);
        });

        add(mainPanel, BorderLayout.CENTER);
        getRootPane().setDefaultButton(loginButton); // touche Entrée
    }

    // 🔧 Méthode utilitaire pour créer un champ avec label
    private JPanel createLabeledField(String label, JComponent field) {
        JPanel panel = new JPanel(new BorderLayout(5, 0));
        panel.setOpaque(false);
        JLabel jlabel = new JLabel(label);
        jlabel.setFont(REGULAR_FONT);
        jlabel.setForeground(new Color(80, 80, 80));
        field.setFont(REGULAR_FONT);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)
        ));
        panel.add(jlabel, BorderLayout.NORTH);
        panel.add(field, BorderLayout.CENTER);
        return panel;
    }

    // 🔧 Effet de boîte avec ombre
    private JPanel createShadowPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(
                new EmptyBorder(15, 15, 15, 15),
                new SoftBevelBorder(SoftBevelBorder.RAISED,
                        new Color(220, 220, 220),
                        new Color(230, 230, 230),
                        new Color(200, 200, 200),
                        new Color(210, 210, 210))
        ));
        return panel;
    }
}
