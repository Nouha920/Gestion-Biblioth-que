package gestionbibliotheque.dao;

import gestionbibliotheque.model.Livre;
import gestionbibliotheque.util.DBConnexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDao {

    public void ajouterLivre(Livre livre) throws SQLException {
        String sql = "INSERT INTO livre (titre, auteur, isbn, annee, nb_exemplaires) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, livre.getTitre());
            stmt.setString(2, livre.getAuteur());
            stmt.setString(3, livre.getIsbn());
            stmt.setInt(4, livre.getAnnee());
            stmt.setInt(5, livre.getNbExemplaires());
            stmt.executeUpdate();
        }
    }

    public List<Livre> listerLivres() throws SQLException {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT * FROM livre";
        try (Connection conn = DBConnexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                livres.add(new Livre(
                    rs.getInt("id"),
                    rs.getString("titre"),
                    rs.getString("auteur"),
                    rs.getString("isbn"),
                    rs.getInt("annee"),
                    rs.getInt("nb_exemplaires")
                ));
            }
        }
        return livres;
    }
}
