package gestionbibliotheque.ui;

import gestionbibliotheque.dao.EmpruntDao;
import gestionbibliotheque.model.Emprunt;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class EmpruntPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private EmpruntDao empruntDao = new EmpruntDao();

    public EmpruntPanel() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"ID", "ID Livre", "ID Utilisateur", "Date Emprunt", "Date Retour"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton ajouterBtn = new JButton("Enregistrer Emprunt");
        ajouterBtn.addActionListener(e -> ajouterEmprunt());
        add(ajouterBtn, BorderLayout.SOUTH);

        rafraichirTable();
    }

    private void ajouterEmprunt() {
        try {
            int idLivre = Integer.parseInt(JOptionPane.showInputDialog("ID du livre"));
            int idUtilisateur = Integer.parseInt(JOptionPane.showInputDialog("ID de l'utilisateur"));
            Date date = new Date(); // aujourd'hui

            Emprunt e = new Emprunt(idLivre, idUtilisateur, date, null);
            empruntDao.enregistrerEmprunt(e);
            rafraichirTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void rafraichirTable() {
        try {
            List<Emprunt> emprunts = empruntDao.listerEmprunts();
            model.setRowCount(0);
            for (Emprunt e : emprunts) {
                model.addRow(new Object[]{e.getId(), e.getIdLivre(), e.getIdUtilisateur(), e.getDateEmprunt(), e.getDateRetour()});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
