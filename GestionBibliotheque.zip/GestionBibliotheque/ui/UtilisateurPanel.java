package gestionbibliotheque.ui;

import gestionbibliotheque.dao.UtilisateurDao;
import gestionbibliotheque.model.Utilisateur;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class UtilisateurPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private UtilisateurDao utilisateurDao = new UtilisateurDao();

    public UtilisateurPanel() {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"ID", "Nom", "Prénom", "Numéro Adhérent"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JButton ajouterBtn = new JButton("Ajouter Utilisateur");
        ajouterBtn.addActionListener(e -> ajouterUtilisateur());
        add(ajouterBtn, BorderLayout.SOUTH);

        rafraichirTable();
    }

    private void ajouterUtilisateur() {
        String nom = JOptionPane.showInputDialog("Nom");
        String prenom = JOptionPane.showInputDialog("Prénom");
        String numero = JOptionPane.showInputDialog("Numéro d'adhérent");

        Utilisateur u = new Utilisateur(nom, prenom, numero);
        try {
            utilisateurDao.ajouterUtilisateur(u);
            rafraichirTable();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private void rafraichirTable() {
        try {
            List<Utilisateur> utilisateurs = utilisateurDao.listerUtilisateurs();
            model.setRowCount(0);
            for (Utilisateur u : utilisateurs) {
                model.addRow(new Object[]{u.getId(), u.getNom(), u.getPrenom(), u.getNumeroAdherent()});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
