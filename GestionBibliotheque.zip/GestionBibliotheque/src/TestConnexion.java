import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnexion {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/bibliotheque";
        String user = "root";
        String password = ""; // laisse vide si tu es sur XAMPP

        try {
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Connexion réussie à la base de données !");
            conn.close();
        } catch (SQLException e) {
            System.err.println("❌ Échec de connexion : " + e.getMessage());
        }
    }
}
