package gestionbibliotheque.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    private final Color PRIMARY_COLOR = new Color(25, 118, 210);    // Bleu primaire
    private final Color ACCENT_COLOR = new Color(245, 124, 0);      // Orange accent
    private final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Gris très clair
    private final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 22);
    private final Font REGULAR_FONT = new Font("Segoe UI", Font.PLAIN, 14);
    
    public LoginFrame() {
        // Configuration de base
        setTitle("Bibliothèque - Connexion");
        setSize(480, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(BACKGROUND_COLOR);
        setLayout(new BorderLayout(20, 20));
        setResizable(false);
        
        // Panneau principal avec un effet d'ombre
        JPanel mainPanel = createShadowPanel();
        mainPanel.setLayout(new BorderLayout(0, 15));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(25, 30, 25, 30));
        
        // En-tête
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        
        JLabel logoLabel = new JLabel("");
        logoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 42));
        headerPanel.add(logoLabel, BorderLayout.WEST);
        
        JPanel titlePanel = new JPanel(new GridLayout(2, 1));
        titlePanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Bibliothèque Municipale");
        titleLabel.setFont(TITLE_FONT);
        titleLabel.setForeground(PRIMARY_COLOR);
        
        JLabel subtitleLabel = new JLabel("Système de gestion");
        subtitleLabel.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        subtitleLabel.setForeground(new Color(120, 120, 120));
        
        titlePanel.add(titleLabel);
        titlePanel.add(subtitleLabel);
        headerPanel.add(titlePanel, BorderLayout.CENTER);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Formulaire de connexion
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridLayout(3, 1, 0, 15));
        formPanel.setOpaque(false);
        
        // Champ e-mail
        JPanel emailPanel = new JPanel(new BorderLayout(5, 0));
        emailPanel.setOpaque(false);
        JLabel emailLabel = new JLabel("Adresse e-mail");
        emailLabel.setFont(REGULAR_FONT);
        emailLabel.setForeground(new Color(80, 80, 80));
        
        JTextField emailField = new JTextField();
        emailField.setFont(REGULAR_FONT);
        emailField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(4,6,4,6)));
        
        emailPanel.add(emailLabel, BorderLayout.NORTH);
        emailPanel.add(emailField, BorderLayout.CENTER);
        
        // Champ mot de passe
        JPanel passwordPanel = new JPanel(new BorderLayout(5, 0));
        passwordPanel.setOpaque(false);
        JLabel passwordLabel = new JLabel("Mot de passe");
        passwordLabel.setFont(REGULAR_FONT);
        passwordLabel.setForeground(new Color(80, 80, 80));
        
        JPasswordField passwordField = new JPasswordField();
        passwordField.setFont(REGULAR_FONT);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        
        passwordPanel.add(passwordLabel, BorderLayout.NORTH);
        passwordPanel.add(passwordField, BorderLayout.CENTER);
        
        // Bouton de connexion
        JButton loginButton = new JButton("SE CONNECTER");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBackground(PRIMARY_COLOR);
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Effet de survol
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(30, 136, 229)); // Bleu plus clair
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(PRIMARY_COLOR);
            }
        });
        
        formPanel.add(emailPanel);
        formPanel.add(passwordPanel);
        formPanel.add(loginButton);
        
        mainPanel.add(formPanel, BorderLayout.CENTER);
        
        // Panneau inférieur avec lien d'aide
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setOpaque(false);
        
        
        
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        
        add(mainPanel, BorderLayout.CENTER);
        
        // Logique de connexion
        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());
            
            if (email.equals("admin@gmail.com") && password.equals("admin123")) {
                JOptionPane.showMessageDialog(
                    this, 
                    "Connexion réussie ! Bienvenue dans le système.",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE
                );
                dispose(); // Fermer LoginFrame
                new MainMenu().setVisible(true);
            } else {
                // Animation de secousse en cas d'erreur
                
                JLabel errorMessage = new JLabel("Identifiants incorrects. Veuillez réessayer.");
                errorMessage.setForeground(new Color(211, 47, 47));
                
                JOptionPane.showMessageDialog(
                    this,
                    errorMessage,
                    "Erreur d'authentification",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });
        
        // Validation par la touche Entrée
        getRootPane().setDefaultButton(loginButton);
    }
    
    /**
     * Crée un panneau avec un effet d'ombre
     */
    private JPanel createShadowPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(new CompoundBorder(
            new EmptyBorder(15, 15, 15, 15),
            BorderFactory.createCompoundBorder(
                new SoftBevelBorder(SoftBevelBorder.RAISED, 
                    new Color(220, 220, 220), 
                    new Color(230, 230, 230), 
                    new Color(200, 200, 200), 
                    new Color(210, 210, 210)),
                new EmptyBorder(10, 10, 10, 10)
            )
        ));
        return panel;
    }
    
    /**
     * Effet de secousse pour indiquer une erreur de saisie
     */
}
  