package gestionbibliotheque.ui;

import gestionbibliotheque.dao.EmpruntDao;
import gestionbibliotheque.model.Emprunt;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class EmpruntPanel extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private EmpruntDao empruntDao = new EmpruntDao();

    public EmpruntPanel() {
        setLayout(new BorderLayout());

        // 🔹 Titre principal
        JLabel titre = new JLabel("📚 Gestion des Emprunts");
        titre.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titre.setHorizontalAlignment(SwingConstants.CENTER);
        titre.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 🔍 Barre de recherche avancée
        JPanel advancedSearchPanel = new JPanel(new GridLayout(2, 4, 10, 10));
        advancedSearchPanel.setBorder(BorderFactory.createTitledBorder("🔍 Recherche avancée"));

        JTextField userField = new JTextField();
        JTextField livreField = new JTextField();
        JTextField dateField = new JTextField(); // au format yyyy-mm-dd
        JButton searchBtn = new JButton("Rechercher");

        advancedSearchPanel.add(new JLabel("Nom ou Numéro d’adhérent :"));
        advancedSearchPanel.add(userField);
        
        advancedSearchPanel.add(new JLabel()); // espace vide
        advancedSearchPanel.add(searchBtn);

        // Regrouper le titre et la recherche
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(titre, BorderLayout.NORTH);
        topPanel.add(advancedSearchPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        // 🧾 Tableau des emprunts
        model = new DefaultTableModel(new String[]{
                "ID", "ID Livre", "ID Utilisateur", "Date Emprunt", "Date Retour"
        }, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // 🔘 Boutons
        JButton ajouterBtn = new JButton("Enregistrer Emprunt");
        JButton enCoursBtn = new JButton("Afficher emprunts en cours");
        JButton retourBtn = new JButton("Marquer comme retourné");
        JButton afficherTousBtn = new JButton("Afficher tous les emprunts");

        ajouterBtn.setBackground(new Color(0, 123, 255));
        ajouterBtn.setForeground(Color.WHITE);
        enCoursBtn.setBackground(new Color(255, 193, 7));
        retourBtn.setBackground(new Color(40, 167, 69));
        retourBtn.setForeground(Color.WHITE);
        afficherTousBtn.setBackground(new Color(108, 117, 125));
        afficherTousBtn.setForeground(Color.WHITE);

        JPanel btnPanel = new JPanel();
        btnPanel.add(ajouterBtn);
        btnPanel.add(enCoursBtn);
        btnPanel.add(retourBtn);
        btnPanel.add(afficherTousBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // 🎯 Actions
        ajouterBtn.addActionListener(e -> ajouterEmprunt());
        enCoursBtn.addActionListener(e -> afficherEmpruntsEnCours());
        retourBtn.addActionListener(e -> marquerCommeRetourne());
        afficherTousBtn.addActionListener(e -> rafraichirTable());

        // 🔍 Recherche avancée
        searchBtn.addActionListener(e -> {
            String u = userField.getText().trim();
            String l = livreField.getText().trim();
            String d = dateField.getText().trim();

            try {
                List<Emprunt> emprunts = empruntDao.rechercherAvancee(u, l, d);
                model.setRowCount(0);
                for (Emprunt em : emprunts) {
                    model.addRow(new Object[]{
                            em.getId(), em.getIdLivre(), em.getIdUtilisateur(), em.getDateEmprunt(), em.getDateRetour()
                    });
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        // ⬇️ Chargement initial
        rafraichirTable();
    }

    private void ajouterEmprunt() {
        try {
            int idLivre = Integer.parseInt(JOptionPane.showInputDialog("ID du livre :"));
            int idUtilisateur = Integer.parseInt(JOptionPane.showInputDialog("ID de l'utilisateur :"));
            Date dateEmprunt = new Date();

            Emprunt e = new Emprunt(idLivre, idUtilisateur, dateEmprunt, null);
            empruntDao.enregistrerEmprunt(e);
            rafraichirTable();
            JOptionPane.showMessageDialog(this, "✅ Emprunt enregistré !");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "❌ Erreur lors de l'enregistrement.");
        }
    }

    private void afficherEmpruntsEnCours() {
        try {
            List<Emprunt> emprunts = empruntDao.listerEmpruntsEnCours();
            model.setRowCount(0);
            for (Emprunt e : emprunts) {
                model.addRow(new Object[]{
                        e.getId(), e.getIdLivre(), e.getIdUtilisateur(), e.getDateEmprunt(), e.getDateRetour()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void marquerCommeRetourne() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int idEmprunt = (int) model.getValueAt(selectedRow, 0);
            try {
                empruntDao.marquerCommeRetourne(idEmprunt);
                rafraichirTable();
                JOptionPane.showMessageDialog(this, "📘 Livre marqué comme retourné.");
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "❌ Erreur lors du retour.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "❗ Sélectionnez un emprunt.");
        }
    }

    private void rafraichirTable() {
        try {
            List<Emprunt> emprunts = empruntDao.listerEmprunts();
            model.setRowCount(0);
            for (Emprunt e : emprunts) {
                model.addRow(new Object[]{
                        e.getId(), e.getIdLivre(), e.getIdUtilisateur(), e.getDateEmprunt(), e.getDateRetour()
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
