package gestionbibliotheque.dao;

import gestionbibliotheque.model.Livre;
import gestionbibliotheque.util.DBConnexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDao {

    public void ajouterLivre(Livre livre) throws SQLException {
        String sql = "INSERT INTO livre (titre, auteur, isbn, annee, nb_exemplaires) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, livre.getTitre());
            stmt.setString(2, livre.getAuteur());
            stmt.setString(3, livre.getIsbn());
            stmt.setInt(4, livre.getAnnee());
            stmt.setInt(5, livre.getNbExemplaires());
            stmt.executeUpdate();
        }
    }

    public List<Livre> listerLivres() throws SQLException {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT * FROM livre";
        try (Connection conn = DBConnexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Livre livre = new Livre(
                    rs.getInt("id"),
                    rs.getString("titre"),
                    rs.getString("auteur"),
                    rs.getString("isbn"),
                    rs.getInt("annee"),
                    rs.getInt("nb_exemplaires")
                );
                livres.add(livre);
            }
        }
        return livres;
    }

    public List<Livre> rechercherParTitreOuAuteur(String motCle) throws SQLException {
        List<Livre> resultats = new ArrayList<>();
        String sql = "SELECT * FROM livre WHERE titre LIKE ? OR auteur LIKE ?";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            String pattern = "%" + motCle + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Livre l = new Livre(
                    rs.getInt("id"),
                    rs.getString("titre"),
                    rs.getString("auteur"),
                    rs.getString("isbn"),
                    rs.getInt("annee"),
                    rs.getInt("nb_exemplaires")
                );
                resultats.add(l);
            }
        }
        return resultats;
    }

    public void modifierLivre(Livre livre) throws SQLException {
        String sql = "UPDATE livre SET titre=?, auteur=?, isbn=?, annee=?, nb_exemplaires=? WHERE id=?";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, livre.getTitre());
            stmt.setString(2, livre.getAuteur());
            stmt.setString(3, livre.getIsbn());
            stmt.setInt(4, livre.getAnnee());
            stmt.setInt(5, livre.getNbExemplaires());
            stmt.setInt(6, livre.getId());
            stmt.executeUpdate();
        }
    }

    public void supprimerLivre(int id) throws SQLException {
    try (Connection conn = DBConnexion.getConnection()) {

        // Supprimer les emprunts liés à ce livre
        String deleteEmprunts = "DELETE FROM emprunt WHERE id_livre=?";
        try (PreparedStatement stmt1 = conn.prepareStatement(deleteEmprunts)) {
            stmt1.setInt(1, id);
            stmt1.executeUpdate();
        }

        // Supprimer le livre après avoir supprimé ses emprunts
        String deleteLivre = "DELETE FROM livre WHERE id=?";
        try (PreparedStatement stmt2 = conn.prepareStatement(deleteLivre)) {
            stmt2.setInt(1, id);
            stmt2.executeUpdate();
        }
    }
}

}
