package gestionbibliotheque.dao;

import gestionbibliotheque.model.Utilisateur;
import gestionbibliotheque.util.DBConnexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtilisateurDao {

    public void ajouterUtilisateur(Utilisateur u) throws SQLException {
        String sql = "INSERT INTO utilisateur (nom, prenom, numero_adhérent) VALUES (?, ?, ?)";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, u.getNom());
            stmt.setString(2, u.getPrenom());
            stmt.setString(3, u.getNumeroAdherent());
            stmt.executeUpdate();
        }
    }

    public List<Utilisateur> listerUtilisateurs() throws SQLException {
        List<Utilisateur> utilisateurs = new ArrayList<>();
        String sql = "SELECT * FROM utilisateur";
        try (Connection conn = DBConnexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                utilisateurs.add(new Utilisateur(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("prenom"),
                        rs.getString("numero_adhérent")
                ));
            }
        }
        return utilisateurs;
    }

    public void supprimerUtilisateur(int id) throws SQLException {
        String sql = "DELETE FROM utilisateur WHERE id = ?";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
