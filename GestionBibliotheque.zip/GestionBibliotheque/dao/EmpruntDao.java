package gestionbibliotheque.dao;

import gestionbibliotheque.model.Emprunt;
import gestionbibliotheque.util.DBConnexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EmpruntDao {

    public void enregistrerEmprunt(Emprunt e) throws SQLException {
        String sql = "INSERT INTO emprunt (id_livre, id_utilisateur, date_emprunt, date_retour) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnexion.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, e.getIdLivre());
            stmt.setInt(2, e.getIdUtilisateur());
            stmt.setDate(3, new java.sql.Date(e.getDateEmprunt().getTime()));
            stmt.setDate(4, e.getDateRetour() != null ? new java.sql.Date(e.getDateRetour().getTime()) : null);
            stmt.executeUpdate();
        }
    }

    public List<Emprunt> listerEmprunts() throws SQLException {
        List<Emprunt> emprunts = new ArrayList<>();
        String sql = "SELECT * FROM emprunt";
        try (Connection conn = DBConnexion.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Emprunt e = new Emprunt(
                    rs.getInt("id"),
                    rs.getInt("id_livre"),
                    rs.getInt("id_utilisateur"),
                    rs.getDate("date_emprunt"),
                    rs.getDate("date_retour")
                );
                emprunts.add(e);
            }
        }
        return emprunts;
    }
}
